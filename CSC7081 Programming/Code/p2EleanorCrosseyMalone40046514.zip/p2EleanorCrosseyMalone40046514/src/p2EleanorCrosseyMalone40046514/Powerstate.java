/**
 * 
 */
package p2EleanorCrosseyMalone40046514;

/**
 * @author Eleanor Crossey Malone 40046514
 *
 */
public enum Powerstate {
	ON, OFF
}
